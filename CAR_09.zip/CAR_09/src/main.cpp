/*
Autonom Driving Car
 */

#include <Arduino.h>
#include <math.h>

// ==========================================
// 1. DEFINITIONEN & KONSTANTEN
// ==========================================

// --- General ---
#define BAUD                      115200
#define FALSE                     0
#define TRUE                      1
#define TESTBENCH                 0
#define DEBUG                     1


// Motor Links (ehemals Right - Bezeichnungen in deinem neuen Code sind etwas anders, 
// ich habe sie konsistent an die Pins angepasst)
const int GSM1_Speed = 10; 
const int in1 = 9;
const int in2 = 8;

// Motor Rechts (ehemals Left)
const int GSM2_Speed = 5; 
const int in3 = 7;
const int in4 = 6;

// Sensoren
const int sensorMitte = A5;  // Vorher A0
const int sensorRechts = A1; // Vorher A1
const int sensorLinks = A0;  // Vorher A2

// Buttons
const int startButton = A3;  // Vorher BUTTON_BLACK / 11
const int stopButton = A4;   // Vorher BUTTON_RED / 10

// --- State Machine States ---
#define EMERGENCY_STOP            0
#define STOP                      1
#define DRIVE_FORWARD             2
#define DRIVE_BACKWARD            3
#define SHARP_LEFT                4
#define SHARP_RIGHT               5

// --- Configuration Numbers ---
#define FORWARD                   0
#define BACKWARD                  1
#define BACKWARD_THRESHOLD        30
#define FORWARD_THRESHOLD         50
#define FORWARD_MAX_SPEED_THRESHOLD  150

#define MAX_SPEED                 255
#define MID_SPEED                 170
#define LOW_SPEED                 80
#define MIN_SPEED                 45
#define STOP_SPEED                0

#define SPEED_CONTROL_K           (1.0 * (MAX_SPEED - LOW_SPEED) / (FORWARD_MAX_SPEED_THRESHOLD - BACKWARD_THRESHOLD))
#define SPEED_CONTROL_D           (MAX_SPEED - (SPEED_CONTROL_K * FORWARD_MAX_SPEED_THRESHOLD))

#define STRATEGY                  4    // 4 = PID CONTROL
#define MIDDLECONTROL_FACTOR      4    
#define SIDE_DISTANCE             30   
#define SIDECONTROL_FACTOR        0.8  
#define SHARP_TURN_VALUE          75

// --- Sensor Parameters ---
#define AVERAGING                 1
#define PARAM_M_FRONT             15460.45
#define PARAM_D_FRONT             17.1
#define PARAM_K_FRONT             8
#define PARAM_M_RIGHT             6500.16
#define PARAM_D_RIGHT             -10.62
#define PARAM_K_RIGHT             4
#define PARAM_M_LEFT              5718.72
#define PARAM_D_LEFT              -24.09
#define PARAM_K_LEFT              4

// --- PID Configuration ---
#define KP                        2.5   // Proportional 
#define KI                        0  // Integral
#define KD                        1.0   // Derivative
#define PID_BASE_SPEED            150   // Standard-Vorwärtsgeschwindigkeit


// ==========================================
// 2. GLOBALE VARIABLEN
// ==========================================

bool drive_left_backward = FALSE;
bool drive_right_backward = FALSE;

// State Machine
static uint8_t state_new = STOP; // Startet jetzt im STOP (Wartet auf Start-Button)
static uint8_t state = STOP;
static uint8_t state_old = STOP;
static uint8_t speed_left = 0;
static uint8_t speed_right = 0;

// Timeslices
static unsigned long previous_millis_100ms = 0;
static unsigned long previous_millis_20ms = 0;

// IR Sensors
uint16_t ir_sensor_front = 70;
uint16_t ir_sensor_right = 30;
uint16_t ir_sensor_left = 30;
uint16_t ir_sensor_front_last = 70;
uint16_t ir_sensor_right_last = 30;
uint16_t ir_sensor_left_last = 30;
int16_t diff_left_right;


// ==========================================
// 3. HELPER FUNKTIONEN
// ==========================================

uint8_t add16(uint8_t summand1, int16_t summand2) {
  int16_t result = (int16_t)summand1 + summand2;
  if (result > 255) return 255;
  if (result < 0) return 0;
  return (uint8_t)result;
}

uint8_t diff16(uint8_t minuend, int16_t subtrahend) {
  int16_t result = (int16_t)minuend - subtrahend;
  if (result > 255) return 255;
  if (result < 0) return 0;
  return (uint8_t)result;
}


// ==========================================
// 4. MOTOR & SENSOR FUNKTIONEN
// ==========================================

void stop_motors() {
  analogWrite(GSM1_Speed, STOP_SPEED);
  analogWrite(GSM2_Speed, STOP_SPEED);
}

void apply_motor_speeds(void) {
  // Motor Links
  analogWrite(GSM1_Speed, speed_left);
  // Motor Rechts
  analogWrite(GSM2_Speed, speed_right);
}

void measure_ir_distances() {
  uint16_t ir_sensor_front_raw, ir_sensor_right_raw, ir_sensor_left_raw;
  uint16_t ir_sensor_front_new, ir_sensor_right_new, ir_sensor_left_new;

  // Front (sensorMitte)
  ir_sensor_front_raw = analogRead(sensorMitte);
  ir_sensor_front_new = (uint16_t)(PARAM_M_FRONT / (ir_sensor_front_raw + PARAM_D_FRONT)) - PARAM_K_FRONT;
  if (ir_sensor_front_new > 150) ir_sensor_front_new = 151;
  else if (ir_sensor_front_new < 20) ir_sensor_front_new = 19;

  // Right (sensorRechts)
  ir_sensor_right_raw = analogRead(sensorRechts);
  ir_sensor_right_new = (uint16_t)(PARAM_M_RIGHT / (ir_sensor_right_raw + PARAM_D_RIGHT)) - PARAM_K_RIGHT;
  if (ir_sensor_right_new > 80) ir_sensor_right_new = 81;
  else if (ir_sensor_right_new < 10) ir_sensor_right_new = 9;

  // Left (sensorLinks)
  ir_sensor_left_raw = analogRead(sensorLinks);
  ir_sensor_left_new = (uint16_t)(PARAM_M_LEFT / (ir_sensor_left_raw + PARAM_D_LEFT)) - PARAM_K_LEFT;
  if (ir_sensor_left_new > 80) ir_sensor_left_new = 81;
  else if (ir_sensor_left_new < 10) ir_sensor_left_new = 9;

  // Save old values
  ir_sensor_front_last = ir_sensor_front;
  ir_sensor_right_last = ir_sensor_right;
  ir_sensor_left_last = ir_sensor_left;

  #if AVERAGING == 1
    ir_sensor_front = (ir_sensor_front + ir_sensor_front_new) / 2;
    ir_sensor_right = (ir_sensor_right + ir_sensor_right_new) / 2;
    ir_sensor_left = (ir_sensor_left + ir_sensor_left_new) / 2;
  #else
    ir_sensor_front = ir_sensor_front_new;
    ir_sensor_right = ir_sensor_right_new;
    ir_sensor_left = ir_sensor_left_new;
  #endif

  diff_left_right = ir_sensor_left - ir_sensor_right;
}


// ==========================================
// 5. INITIALISIERUNGEN
// ==========================================

void init_motors() {
  pinMode(GSM1_Speed, OUTPUT); 
  pinMode(in1, OUTPUT); 
  pinMode(in2, OUTPUT);
  
  pinMode(GSM2_Speed, OUTPUT); 
  pinMode(in3, OUTPUT); 
  pinMode(in4, OUTPUT);

  // Setze Standard-Richtung (Vorwärts) für den L298N/L293D Treiber
  digitalWrite(in1, HIGH); 
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW); 
  digitalWrite(in4, HIGH);

  stop_motors();
}

void init_buttons(void) { 
  pinMode(startButton, INPUT_PULLUP); 
  pinMode(stopButton, INPUT_PULLUP); 
}

void init_uart(void) { 
  Serial.begin(BAUD); 
  Serial.println("Serial started..."); 
}


// ==========================================
// 6. INPUT & DEBUG FUNKTIONEN
// ==========================================

void handle_button_inputs(void) {
  if (digitalRead(stopButton) == LOW) {
    state_new = STOP;
  }
  else if (digitalRead(startButton) == LOW && state_new == STOP) {
     delay(50); // Einfaches Entprellen
     if (digitalRead(startButton) == LOW) {
        state_new = DRIVE_FORWARD;
     }
  }
}

void debug_output() {
  Serial.print("State:\t"); Serial.print(state);
  Serial.print("\tF:\t"); Serial.print(ir_sensor_front);
  Serial.print("\tR:\t"); Serial.print(ir_sensor_right);
  Serial.print("\tL:\t"); Serial.print(ir_sensor_left);
  Serial.print("\tDiff:\t"); Serial.println(diff_left_right);
}


// ==========================================
// 7. STRATEGIEN (INKL. PID)
// ==========================================

void strategy_pid_control(void) {
  static int16_t pid_integral = 0;
  static int16_t pid_last_error = 0;

  int16_t error = diff_left_right;

  float p_term = KP * error;
  
  pid_integral += error;
  pid_integral = constrain(pid_integral, -100, 100); // Anti-Windup
  float i_term = KI * pid_integral;

  float d_term = KD * (error - pid_last_error);
  pid_last_error = error;

  int16_t pid_adjustment = (int16_t)(p_term + i_term + d_term);

  // Anwenden der Anpassung. diff16 und add16 schützen vor Over/Underflow (<0 oder >255)
  speed_left = diff16(PID_BASE_SPEED, pid_adjustment); 
  speed_right = add16(PID_BASE_SPEED, pid_adjustment);

  // Sicherheits-Override: Wand direkt voraus
  if (ir_sensor_front < BACKWARD_THRESHOLD) {
    speed_left = STOP_SPEED;
    speed_right = STOP_SPEED;
    state_new = DRIVE_BACKWARD;
    pid_integral = 0; // Reset des Integrals bei Stopp
  }
}


// ==========================================
// 8. STATE MACHINE
// ==========================================

void handle_emergency_stop(void) {
  speed_left = STOP_SPEED; 
  speed_right = STOP_SPEED;
}

void handle_stop(void) {
  speed_left = STOP_SPEED; 
  speed_right = STOP_SPEED;
  // Auto bleibt stehen, bis Start-Button gedrückt wird
}

void handle_drive_forward(void) {
  if (state_old == DRIVE_BACKWARD) {
    // Motoren stoppen und auf Vorwärts umschalten
    digitalWrite(in1, LOW); 
    digitalWrite(in2, LOW);
    digitalWrite(in3, LOW); 
    digitalWrite(in4, LOW);
    stop_motors();
    // Non-blocking Verzögerung wäre hier besser, aber zur Einfachheit erstmal übernommen:
    delay(300); 
  }

  drive_left_backward = FALSE;
  drive_right_backward = FALSE;
  
  // Richtung: Vorwärts
  digitalWrite(in1, HIGH); 
  digitalWrite(in2, LOW);
  digitalWrite(in3, LOW); 
  digitalWrite(in4, HIGH);

  strategy_pid_control();
}

void handle_drive_backward(void) {
  if (state_old != DRIVE_BACKWARD) {
    // Motoren stoppen und auf Rückwärts umschalten
    digitalWrite(in1, LOW); 
    digitalWrite(in2, LOW);
    digitalWrite(in3, LOW); 
    digitalWrite(in4, LOW);
    stop_motors();
    delay(300); 
  }

  drive_left_backward = TRUE;
  drive_right_backward = TRUE;
  
  // Richtung: Rückwärts
  digitalWrite(in1, LOW); 
  digitalWrite(in2, HIGH);
  digitalWrite(in3, HIGH); 
  digitalWrite(in4, LOW);

  speed_left = MID_SPEED; 
  speed_right = speed_left;

  if (ir_sensor_front >= FORWARD_THRESHOLD) {
    speed_left = STOP_SPEED; 
    speed_right = STOP_SPEED;
    state_new = DRIVE_FORWARD;
  }
}

void process_state_machine(void) {
  state_old = state;
  state = state_new;

  switch (state) {
    case EMERGENCY_STOP: handle_emergency_stop(); break;
    case STOP: handle_stop(); break;
    case DRIVE_FORWARD: handle_drive_forward(); break;
    case DRIVE_BACKWARD: handle_drive_backward(); break;
    default: break;
  }
}


// ==========================================
// 9. HAUPTSCHLEIFEN (SETUP & LOOP)
// ==========================================

void setup(void) {
  init_uart();
  init_buttons();
  init_motors();
}

void loop(void) {
  handle_button_inputs();

  // 100ms Timeslice
  if (millis() - previous_millis_100ms >= 100) {
    previous_millis_100ms = millis();
    debug_output();
  }

  // 20ms Timeslice
  if (millis() - previous_millis_20ms >= 20) {
    previous_millis_20ms = millis();
    measure_ir_distances();
    process_state_machine();
    apply_motor_speeds();
  }
}